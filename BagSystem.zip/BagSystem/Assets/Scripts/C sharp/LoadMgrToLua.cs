﻿using SLua;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CustomLuaClass]
public class LoadMgrToLua 
{
    public ABMgr GetABMgr()
    {
        return ABMgr.GetInstance();
    }
}
