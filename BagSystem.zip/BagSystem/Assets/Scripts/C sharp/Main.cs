﻿using UnityEngine;
using System.Collections;
using SLua;
using System.IO;
using System;

public class Main : MonoBehaviour 
{
	// private static LuaState ls_state;

	// void Start () 
	// {
	// 	ls_state = new LuaState();
	// 	//设置脚本启动代理
	// 	ls_state.loaderDelegate = ((string fn, ref string absoluteFn) => {
	// 		//获取Lua文件执行目录
	// 		string file_path = Directory.GetCurrentDirectory() + "/Assets/Resources/" + fn;
	// 		Debug.Log(file_path);
	// 		return File.ReadAllBytes(file_path); 
	// 	});

	// 	ls_state.doFile("Main.lua");

	// }



	LuaSvr lua_svr;
	void Start() {
		lua_svr = new LuaSvr();

		LuaSvr.mainState.loaderDelegate += MyCustomLoader;
		//LuaSvr.mainState.loaderDelegate += MyCustomABLoader;

		lua_svr.init(null, () => 
		{
            lua_svr.start("Main");
		});

		
	}

	//https://blog.csdn.net/qq_39824797/article/details/88868309
	private byte[] MyCustomLoader(string strFile, ref string absoluteFn)
    {
        string filename = Application.dataPath + "/Scripts/Lua/" + strFile + ".txt";

		if(File.Exists(filename))
		{
        	return File.ReadAllBytes(filename);
		}
		else
		{
			Debug.Log("文件找不到，文件名为 " + strFile);
		}
		return null;
    }

	//加载AB包中的LUA文件
	private byte[] MyCustomABLoader(string strFile, ref string absoluteFn)
    {
		if(strFile == null)
		{
			return null;
		}
		Debug.Log("AB包加载");

		//加载AB包
		string path = Application.streamingAssetsPath + "/lua";
		AssetBundle ab = AssetBundle.LoadFromFile(path);

		//加载lua文件
		TextAsset tx = ab.LoadAsset<TextAsset>(strFile);

		return tx.bytes;
	}

	// public void DoString(string str)
	// {
	// 	if(lua_svr == null)
	// 	{
	// 		Debug.Log("未初始化");
	// 	}
	// 	LuaSvr.mainState.doString(str);
	// }

	// public void Dispose()
	// {
	// 	LuaSvr.mainState.Dispose();
	// 	lua_svr = null;
	// }



}